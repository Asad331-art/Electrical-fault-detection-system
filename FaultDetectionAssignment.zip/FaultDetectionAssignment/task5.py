
import os
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler


# ==========================================
# TASK 5: TEST ONCE
# ==========================================

BASE_DIR = r"C:\Users\Laptop Zone\Downloads\FaultDetectionAssignment"

DATA_PATH = os.path.join(
    BASE_DIR, "data", "detect_dataset.csv"
)

MODEL_DIR = os.path.join(BASE_DIR, "models")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

os.makedirs(RESULTS_DIR, exist_ok=True)


# ==========================================
# 5.1 IMPLEMENT ACCURACY MANUALLY
# ==========================================

def accuracy(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have equal lengths.")

    if len(y_true) == 0:
        raise ValueError("Cannot calculate accuracy for empty data.")

    correct = np.sum(y_true == y_pred)
    return correct / len(y_true)


# ==========================================
# 5.1 IMPLEMENT CONFUSION MATRIX MANUALLY
# Rows = actual class; columns = predicted class
# Order: [[TN, FP], [FN, TP]]
# ==========================================

def confusion_matrix(y_true, y_pred):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have equal lengths.")

    tn = np.sum((y_true == 0) & (y_pred == 0))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    tp = np.sum((y_true == 1) & (y_pred == 1))

    return np.array([
        [tn, fp],
        [fn, tp]
    ], dtype=int)


# ==========================================
# 2. LOAD AND PREPARE DATA
# ==========================================

df = pd.read_csv(DATA_PATH)

feature_cols = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]
target_col = "Output (S)"

df = df[feature_cols + [target_col]].dropna().copy()

X_raw = df[feature_cols].to_numpy(dtype=float)
y = df[target_col].to_numpy(dtype=int)

# Use exactly the same split as Tasks 3 and 4
rng = np.random.default_rng(42)
idx = rng.permutation(len(df))

n_train = int(0.6 * len(df))
n_val = int(0.2 * len(df))

train_idx = idx[:n_train]
val_idx = idx[n_train:n_train + n_val]
test_idx = idx[n_train + n_val:]

X_train_raw = X_raw[train_idx]
X_test_raw = X_raw[test_idx]

y_train = y[train_idx]
y_test = y[test_idx]

print("Dataset loaded successfully.")
print("Training rows:", len(train_idx))
print("Validation rows:", len(val_idx))
print("Test rows:", len(test_idx))


# ==========================================
# 3. PREPARE SET R: SIX STANDARDIZED FEATURES
# ==========================================

scaler_R = StandardScaler()

X_train_R = scaler_R.fit_transform(X_train_raw)
X_test_R = scaler_R.transform(X_test_raw)


# ==========================================
# 4. PREPARE SET Q: SIX FEATURES + SQUARES
# Calculate squares BEFORE standardization
# ==========================================

X_train_Q_raw = np.column_stack([
    X_train_raw,
    X_train_raw ** 2
])

X_test_Q_raw = np.column_stack([
    X_test_raw,
    X_test_raw ** 2
])

scaler_Q = StandardScaler()

X_train_Q = scaler_Q.fit_transform(X_train_Q_raw)
X_test_Q = scaler_Q.transform(X_test_Q_raw)


# ==========================================
# 5. LOGISTIC REGRESSION PARAMETERS
# From the Task 3 output
# ==========================================

theta_R = np.array([
    -0.1610120917,
     0.0897648792,
    -0.1366799367,
     0.2170727299,
    -0.0575008279,
     0.0543866822,
     0.0010255261
])

theta_Q = np.array([
    24.9209141224,
     2.3272915931,
    -5.3580838672,
    -1.7365031310,
    -0.5335687130,
     0.4167264098,
     0.0985796277,
    18.8912382991,
     4.7542559116,
    13.9569180396,
    -6.0276364341,
    -6.4642583654,
    -6.1407454567
])


# ==========================================
# 6. LOGISTIC REGRESSION PREDICTIONS
# ==========================================

def sigmoid(z):
    z = np.clip(z, -500, 500)
    return 1.0 / (1.0 + np.exp(-z))


def logistic_predict(X, theta):
    # Add intercept column x0 = 1
    X_with_intercept = np.column_stack([
        np.ones(X.shape[0]),
        X
    ])

    probabilities = sigmoid(X_with_intercept @ theta)

    return (probabilities >= 0.5).astype(int)


# ==========================================
# 7. LOAD THE BEST SVM MODELS FROM TASK 4
# ==========================================

linear_path = os.path.join(
    MODEL_DIR, "task4_best_linear_svm.joblib"
)

rbf_path = os.path.join(
    MODEL_DIR, "task4_best_rbf_svm.joblib"
)

if not os.path.exists(linear_path):
    raise FileNotFoundError(
        "Best linear SVM not found. Run task4.py first."
    )

if not os.path.exists(rbf_path):
    raise FileNotFoundError(
        "Best RBF SVM not found. Run task4.py first."
    )

linear_saved = joblib.load(linear_path)
rbf_saved = joblib.load(rbf_path)

linear_model = linear_saved["model"]
rbf_model = rbf_saved["model"]

# Use the exact scaler saved with each SVM model
linear_scaler = linear_saved["scaler"]
rbf_scaler = rbf_saved["scaler"]

X_test_linear = linear_scaler.transform(X_test_raw)
X_test_rbf = rbf_scaler.transform(X_test_raw)


# ==========================================
# 8. EVALUATE EACH FINAL MODEL ON TEST DATA
# Each model is evaluated once
# ==========================================

predictions = {
    "Logistic Regression - Set R":
        logistic_predict(X_test_R, theta_R),

    "Logistic Regression - Set Q":
        logistic_predict(X_test_Q, theta_Q),

    "Best Linear SVM":
        linear_model.predict(X_test_linear),

    "Best RBF SVM":
        rbf_model.predict(X_test_rbf)
}


# ==========================================
# 9. REPORT ACCURACY, CONFUSION MATRIX,
#    AND MISSED FAULTS
# ==========================================

summary_rows = []

print("\n========== TASK 5 TEST RESULTS ==========")
print("Confusion matrix format: [[TN, FP], [FN, TP]]")
print("Missed faults = FN = actual 1, predicted 0")

for model_name, y_pred in predictions.items():

    acc = accuracy(y_test, y_pred)
    cm = confusion_matrix(y_test, y_pred)

    tn = cm[0, 0]
    fp = cm[0, 1]
    fn = cm[1, 0]
    tp = cm[1, 1]

    print("\nModel:", model_name)
    print(f"Accuracy: {acc * 100:.2f}%")
    print("Confusion Matrix:")
    print(cm)
    print("True Negatives (TN):", tn)
    print("False Positives (FP):", fp)
    print("False Negatives (FN):", fn)
    print("True Positives (TP):", tp)
    print("Missed Faults:", fn)

    summary_rows.append({
        "Model": model_name,
        "Test Accuracy (%)": acc * 100,
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "TP": tp,
        "Missed Faults": fn
    })


# ==========================================
# 10. SAVE FINAL TEST RESULTS
# ==========================================

results_df = pd.DataFrame(summary_rows)

results_path = os.path.join(
    RESULTS_DIR, "task5_test_results.csv"
)

results_df.to_csv(results_path, index=False)

print("\n========== FINAL SUMMARY TABLE ==========")
print(results_df.to_string(
    index=False,
    formatters={
        "Test Accuracy (%)": lambda x: f"{x:.2f}%"
    }
))

print("\nResults saved to:")
print(results_path)

print("\nTASK 5 FINISHED SUCCESSFULLY.")