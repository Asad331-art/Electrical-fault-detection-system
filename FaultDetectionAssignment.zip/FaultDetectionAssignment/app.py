
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# --------------------------------------------------
# PATHS AND SETTINGS
# --------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "detect_dataset.csv"
MODEL_DIR = BASE_DIR / "models"

FEATURES = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]
TARGET = "Output (S)"

st.set_page_config(
    page_title="Electrical Fault Detection",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --------------------------------------------------
# WHITE INDUSTRIAL DASHBOARD STYLE
# --------------------------------------------------
st.markdown(
    """
    <style>
    .stApp {
        background-color: #FFFFFF;
        color: #172033;
    }

    [data-testid="stHeader"] {
        background: #FFFFFF;
    }

    [data-testid="stSidebar"] {
        background-color: #F4F7FB;
        border-right: 1px solid #E2E8F0;
    }

    h1, h2, h3 {
        color: #152238 !important;
    }

    p, label, [data-testid="stMarkdownContainer"] {
        color: #334155;
    }

    div[data-testid="stMetric"] {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 16px;
    }

    div[data-testid="stMetricValue"] {
        color: #155EEF;
    }

    div.stButton > button {
        background-color: #155EEF;
        color: white;
        border: none;
        border-radius: 8px;
        min-height: 42px;
        font-weight: 600;
    }

    div.stButton > button:hover {
        background-color: #124BC4;
        color: white;
        border: none;
    }

    div[data-testid="stDataFrame"] {
        border: 1px solid #E2E8F0;
        border-radius: 8px;
    }

    .dashboard-subtitle {
        color: #64748B;
        font-size: 16px;
        margin-top: -10px;
    }

    .section-note {
        color: #64748B;
        font-size: 13px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# --------------------------------------------------
# DATA AND MODEL LOADING
# --------------------------------------------------
@st.cache_data
def load_dataset():
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Dataset not found: {DATA_FILE}"
        )

    data = pd.read_csv(DATA_FILE)
    data.columns = data.columns.str.strip()

    required = FEATURES + [TARGET]
    missing = [col for col in required if col not in data.columns]

    if missing:
        raise ValueError(
            f"Missing columns: {missing}. "
            f"CSV columns found: {list(data.columns)}"
        )

    for col in required:
        data[col] = pd.to_numeric(data[col], errors="coerce")

    data = data.dropna(subset=required).reset_index(drop=True)

    if not data[TARGET].isin([0, 1]).all():
        raise ValueError(
            f"{TARGET} must contain only binary labels 0 and 1."
        )

    data[TARGET] = data[TARGET].astype(int)
    return data


@st.cache_resource
def load_models():
    logistic_path = MODEL_DIR / "task3_best_Set_Q.joblib"
    svm_path = MODEL_DIR / "task4_best_rbf_svm.joblib"

    if not logistic_path.exists():
        raise FileNotFoundError(
            f"Missing Logistic Regression artifact: {logistic_path}\n"
            "Save the genuine trained Set-Q coefficients and scaler "
            "from Task 3 before using this dashboard."
        )

    if not svm_path.exists():
        raise FileNotFoundError(
            f"Missing RBF SVM artifact: {svm_path}\n"
            "Run task4.py first to train and save the SVM."
        )

    logistic_artifact = joblib.load(logistic_path)
    svm_artifact = joblib.load(svm_path)

    if "scaler" not in logistic_artifact:
        raise ValueError(
            "The Logistic Regression artifact has no saved scaler."
        )

    if "theta" not in logistic_artifact:
        raise ValueError(
            "The Logistic Regression artifact must contain 'theta'."
        )

    if "model" not in svm_artifact or "scaler" not in svm_artifact:
        raise ValueError(
            "The SVM artifact must contain 'model' and 'scaler'."
        )

    theta = np.asarray(logistic_artifact["theta"], dtype=float)

    if theta.size != 13:
        raise ValueError(
            "Set-Q theta must contain 13 values: "
            "one intercept and 12 feature coefficients."
        )

    if logistic_artifact["scaler"].n_features_in_ != 12:
        raise ValueError(
            "The Set-Q scaler must be fitted on 12 features."
        )

    if svm_artifact["scaler"].n_features_in_ != 6:
        raise ValueError(
            "The SVM scaler must be fitted on the six raw features."
        )

    return logistic_artifact, svm_artifact


def predict_logistic(values, artifact):
    raw = np.asarray(values, dtype=float).reshape(1, 6)
    set_q = np.column_stack([raw, raw ** 2])

    scaled = artifact["scaler"].transform(set_q)
    x = np.column_stack([np.ones(1), scaled])

    theta = np.asarray(artifact["theta"], dtype=float)
    z = float(np.clip(x @ theta, -500, 500)[0])

    probability = 1.0 / (1.0 + np.exp(-z))
    prediction = int(probability >= 0.5)

    return prediction, probability


def predict_svm(values, artifact):
    raw = np.asarray(values, dtype=float).reshape(1, 6)
    scaled = artifact["scaler"].transform(raw)

    prediction = int(artifact["model"].predict(scaled)[0])
    return prediction


def apply_chart_style(fig, height=350):
    fig.update_layout(
        height=height,
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(
            family="Arial, sans-serif",
            color="#334155",
            size=12,
        ),
        margin=dict(l=20, r=20, t=55, b=30),
        legend=dict(
            bgcolor="rgba(255,255,255,0.8)",
            bordercolor="#E2E8F0",
            borderwidth=1,
        ),
    )

    fig.update_xaxes(
        showgrid=True,
        gridcolor="#E9EEF5",
        zerolinecolor="#CBD5E1",
    )

    fig.update_yaxes(
        showgrid=True,
        gridcolor="#E9EEF5",
        zerolinecolor="#CBD5E1",
    )

    return fig


# --------------------------------------------------
# HEADER
# --------------------------------------------------
st.title("⚡ Electrical Fault Detection System")
st.markdown(
    '<div class="dashboard-subtitle">'
    'Industrial electrical measurements • Dataset analytics • '
    'Machine learning predictions'
    '</div>',
    unsafe_allow_html=True,
)
st.write("")

try:
    df = load_dataset()
    logistic_artifact, svm_artifact = load_models()
except Exception as exc:
    st.error(str(exc))
    st.stop()

df["Sample"] = np.arange(1, len(df) + 1)
df["Condition"] = df[TARGET].map({
    0: "No Fault",
    1: "Fault",
})

total_rows = len(df)
fault_count = int((df[TARGET] == 1).sum())
normal_count = int((df[TARGET] == 0).sum())
fault_percentage = (
    100 * fault_count / total_rows if total_rows else 0
)

# --------------------------------------------------
# SIDEBAR NAVIGATION
# --------------------------------------------------
st.sidebar.title("⚡ Control Panel")
st.sidebar.caption("Electrical Fault Monitoring")

page = st.sidebar.radio(
    "Navigate",
    [
        "Dashboard Overview",
        "Dataset Graphs",
        "Fault Prediction",
        "Dataset Explorer",
    ],
)

st.sidebar.divider()
st.sidebar.markdown("**Dataset information**")
st.sidebar.write(f"Valid records: {total_rows:,}")
st.sidebar.write(f"Features: {len(FEATURES)}")
st.sidebar.write("Target: Output (S)")
st.sidebar.caption(
    "This dashboard uses recorded CSV data. "
    "It is not connected to live sensors."
)

# --------------------------------------------------
# PAGE 1: OVERVIEW
# --------------------------------------------------
if page == "Dashboard Overview":
    st.subheader("System Overview")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Total Records", f"{total_rows:,}")
    c2.metric("Fault Records", f"{fault_count:,}")
    c3.metric("Normal Records", f"{normal_count:,}")
    c4.metric("Fault Percentage", f"{fault_percentage:.2f}%")

    st.divider()

    left, right = st.columns(2)

    with left:
        st.subheader("Fault vs No-Fault Records")

        distribution = pd.DataFrame({
            "Condition": ["No Fault", "Fault"],
            "Records": [normal_count, fault_count],
        })

        fig = px.bar(
            distribution,
            x="Condition",
            y="Records",
            color="Condition",
            color_discrete_map={
                "No Fault": "#16A34A",
                "Fault": "#DC2626",
            },
            text="Records",
            title="Distribution of Dataset Labels",
        )

        fig.update_traces(textposition="outside")
        fig.update_layout(showlegend=False)
        st.plotly_chart(
            apply_chart_style(fig),
            use_container_width=True,
        )

    with right:
        st.subheader("Dataset Class Proportion")

        pie_data = pd.DataFrame({
            "Condition": ["No Fault", "Fault"],
            "Records": [normal_count, fault_count],
        })

        fig = px.pie(
            pie_data,
            names="Condition",
            values="Records",
            hole=0.55,
            color="Condition",
            color_discrete_map={
                "No Fault": "#16A34A",
                "Fault": "#DC2626",
            },
            title="Class Balance",
        )

        fig.update_traces(
            textposition="inside",
            textinfo="label+percent",
        )
        st.plotly_chart(
            apply_chart_style(fig),
            use_container_width=True,
        )

    st.divider()
    st.subheader("Measurement Statistics")

    stats = df[FEATURES].describe().T
    stats = stats.rename(columns={
        "count": "Count",
        "mean": "Mean",
        "std": "Std. Dev.",
        "min": "Minimum",
        "25%": "25%",
        "50%": "Median",
        "75%": "75%",
        "max": "Maximum",
    })

    st.dataframe(
        stats.round(4),
        use_container_width=True,
    )


# --------------------------------------------------
# PAGE 2: DATASET GRAPHS
# --------------------------------------------------
elif page == "Dataset Graphs":
    st.subheader("Dataset Visualization")
    st.caption(
        "All graphs below are generated from the measurements "
        "and labels in your actual CSV file."
    )

    st.markdown("### 1. Measurement trends by sample")

    graph_size = st.selectbox(
        "Number of samples to display",
        options=[500, 1000, 2000, 5000, "All records"],
        index=1,
    )

    if graph_size == "All records":
        plot_df = df.copy()
    else:
        plot_df = df.head(int(graph_size)).copy()

    st.caption(f"Displaying {len(plot_df):,} of {total_rows:,} records.")

    # Each graph keeps the original measurement units.
    for start in range(0, len(FEATURES), 2):
        chart_cols = st.columns(2)

        for offset, feature_index in enumerate(
            range(start, min(start + 2, len(FEATURES)))
        ):
            feature = FEATURES[feature_index]

            with chart_cols[offset]:
                fig = px.scatter(
                    plot_df,
                    x="Sample",
                    y=feature,
                    color="Condition",
                    color_discrete_map={
                        "No Fault": "#16A34A",
                        "Fault": "#DC2626",
                    },
                    opacity=0.7,
                    render_mode="webgl",
                    title=f"{feature} vs Sample Number",
                    labels={
                        "Sample": "Sample number",
                        feature: feature,
                        "Condition": "Actual dataset label",
                    },
                )

                fig.update_traces(marker=dict(size=5))
                st.plotly_chart(
                    apply_chart_style(fig, height=320),
                    use_container_width=True,
                )

    st.divider()
    st.markdown("### 2. Current measurements")

    current_features = ["Ia", "Ib", "Ic"]

    fig = px.scatter(
        plot_df,
        x="Ia",
        y="Ib",
        color="Condition",
        size=None,
        color_discrete_map={
            "No Fault": "#16A34A",
            "Fault": "#DC2626",
        },
        opacity=0.65,
        render_mode="webgl",
        title="Phase Current: Ia vs Ib",
    )

    st.plotly_chart(
        apply_chart_style(fig),
        use_container_width=True,
    )

    st.divider()
    st.markdown("### 3. Voltage measurements")

    voltage_features = ["Va", "Vb", "Vc"]

    fig = px.scatter(
        plot_df,
        x="Va",
        y="Vb",
        color="Condition",
        color_discrete_map={
            "No Fault": "#16A34A",
            "Fault": "#DC2626",
        },
        opacity=0.65,
        render_mode="webgl",
        title="Phase Voltage: Va vs Vb",
    )

    st.plotly_chart(
        apply_chart_style(fig),
        use_container_width=True,
    )

    st.divider()
    st.markdown("### 4. Feature correlation heatmap")

    correlation = df[FEATURES].corr()

    fig = go.Figure(
        data=go.Heatmap(
            z=correlation.values,
            x=correlation.columns,
            y=correlation.index,
            zmin=-1,
            zmax=1,
            colorscale="RdBu",
            reversescale=True,
            text=np.round(correlation.values, 2),
            texttemplate="%{text}",
            colorbar=dict(title="Correlation"),
        )
    )

    fig.update_layout(
        title="Correlation Between Electrical Measurements",
        xaxis_title="Features",
        yaxis_title="Features",
    )

    st.plotly_chart(
        apply_chart_style(fig, height=480),
        use_container_width=True,
    )

    st.info(
        "Correlation indicates how measurements vary together. "
        "It does not prove that one feature causes an electrical fault."
    )


# --------------------------------------------------
# PAGE 3: FAULT PREDICTION
# --------------------------------------------------
elif page == "Fault Prediction":
    st.subheader("Fault Prediction")
    st.caption(
        "Choose a recorded row or enter six measurements manually."
    )

    input_mode = st.radio(
        "Measurement source",
        ["Select dataset row", "Enter measurements manually"],
        horizontal=True,
    )

    selected_row = None

    if input_mode == "Select dataset row":
        row_number = st.selectbox(
            "Select dataset sample",
            options=list(range(total_rows)),
            format_func=lambda i: (
                f"Sample {i + 1} — "
                f"{df.iloc[i]['Condition']}"
            ),
        )

        selected_row = df.iloc[row_number]
        values = selected_row[FEATURES].to_numpy(dtype=float)

        st.dataframe(
            pd.DataFrame([values], columns=FEATURES),
            use_container_width=True,
            hide_index=True,
        )

        st.caption(
            f"Actual dataset label: {selected_row['Condition']}"
        )

    else:
        default_values = df[FEATURES].median()

        measurement_cols = st.columns(3)
        values = []

        for i, feature in enumerate(FEATURES):
            with measurement_cols[i % 3]:
                value = st.number_input(
                    feature,
                    value=float(default_values[feature]),
                    format="%.5f",
                    key=f"manual_{feature}",
                )
                values.append(value)

        values = np.asarray(values, dtype=float)

    st.write("")

    if st.button("Run Fault Detection", type="primary"):
        try:
            logistic_prediction, probability = predict_logistic(
                values, logistic_artifact
            )
            svm_prediction = predict_svm(
                values, svm_artifact
            )

            st.divider()
            st.subheader("Prediction Results")

            col1, col2 = st.columns(2)

            with col1:
                st.markdown("#### Set-Q Logistic Regression")

                if logistic_prediction == 1:
                    st.error("FAULT DETECTED")
                else:
                    st.success("NO FAULT")

                st.metric(
                    "Estimated fault probability",
                    f"{probability:.2%}",
                )

            with col2:
                st.markdown("#### RBF Support Vector Machine")

                if svm_prediction == 1:
                    st.error("FAULT DETECTED")
                else:
                    st.success("NO FAULT")

                st.metric(
                    "Predicted class",
                    str(svm_prediction),
                )

            st.divider()
            st.subheader("Model Agreement")

            if logistic_prediction == svm_prediction:
                st.success("Both models predict the same class.")
            else:
                st.warning(
                    "The models disagree. Review this sample carefully."
                )

            if selected_row is not None:
                actual = int(selected_row[TARGET])

                st.markdown("#### Comparison with actual dataset label")
                result_cols = st.columns(3)

                result_cols[0].metric("Actual label", actual)
                result_cols[1].metric(
                    "Logistic prediction",
                    logistic_prediction,
                )
                result_cols[2].metric(
                    "RBF SVM prediction",
                    svm_prediction,
                )

                if (
                    logistic_prediction == actual
                    and svm_prediction == actual
                ):
                    st.success(
                        "Both model predictions match the dataset label."
                    )
                else:
                    st.warning(
                        "At least one model prediction differs from "
                        "the dataset label."
                    )
            else:
                st.caption(
                    "Manual input has no known actual label, so "
                    "accuracy against a true label cannot be calculated."
                )

        except Exception as exc:
            st.error(f"Prediction failed: {exc}")


# --------------------------------------------------
# PAGE 4: DATASET EXPLORER
# --------------------------------------------------
elif page == "Dataset Explorer":
    st.subheader("Dataset Explorer")
    st.caption("Filter and inspect the recorded electrical measurements.")

    selected_condition = st.multiselect(
        "Filter by actual condition",
        options=["No Fault", "Fault"],
        default=["No Fault", "Fault"],
    )

    filtered_df = df[df["Condition"].isin(selected_condition)]

    selected_features = st.multiselect(
        "Select measurement columns",
        options=FEATURES,
        default=FEATURES,
    )

    st.metric("Filtered Records", f"{len(filtered_df):,}")

    display_columns = ["Sample"] + selected_features + [
        TARGET,
        "Condition",
    ]

    st.dataframe(
        filtered_df[display_columns].head(2000),
        use_container_width=True,
        hide_index=True,
    )

    st.caption(
        "The table displays at most 2,000 filtered rows for readability."
    )

    csv_data = filtered_df.drop(
        columns=["Sample", "Condition"]
    ).to_csv(index=False).encode("utf-8")

    st.download_button(
        label="Download filtered data as CSV",
        data=csv_data,
        file_name="filtered_fault_detection_data.csv",
        mime="text/csv",
    )


# --------------------------------------------------
# FOOTER
# --------------------------------------------------
st.divider()
st.caption(
    "Academic demonstration using recorded dataset measurements "
    "and saved machine-learning models. This dashboard is not a "
    "certified electrical protection system and does not read live sensors."
)