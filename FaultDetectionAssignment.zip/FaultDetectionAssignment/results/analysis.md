# Task 6 — Analysis

## 6.1 Logistic regression on Set R vs. linear SVM

Logistic regression on Set R achieved a validation accuracy of
**73.08%**. The best linear SVM achieved
**72.58%** with
C = 0.1.

Both models use the same six standardized electrical measurements
and learn a linear decision boundary. Logistic regression minimizes
logistic loss, while a linear SVM seeks a large-margin boundary.
Their accuracies can be similar because both are trying to separate
the same classes using a linear combination of the same features.

Similar performance suggests that a linear boundary captures some
of the relationship between the measurements and fault labels. It
does not prove that the classes are perfectly linearly separable.

## 6.2 Signs of the Set Q squared-feature weights

| Squared Feature | Weight | Sign |
| --- | --- | --- |
| Ia^2 | 18.89 | Positive |
| Ib^2 | 4.75 | Positive |
| Ic^2 | 13.96 | Positive |
| Va^2 | -6.03 | Negative |
| Vb^2 | -6.46 | Negative |
| Vc^2 | -6.14 | Negative |

The weights for all three squared-current features are positive.
This is consistent with many electrical faults causing current
magnitude to increase. When other features are held constant,
larger squared-current values tend to push the model toward the
fault class.

The weights for all three squared-voltage features are negative.
This is consistent with many faults causing voltage magnitude to
drop. Larger squared-voltage values tend to push the prediction
away from the fault class, while smaller values can support a
fault prediction.

These are learned statistical associations, not universal rules
for every fault type. Each weight must be interpreted together
with the other features and the standardization procedure.

## 6.3 Number of support vectors

The best linear SVM used **5849**
support vectors. The best RBF SVM used
**266** support vectors.

A very large number of support vectors means that many training
samples contribute to defining the decision boundary. This may
occur when classes overlap or many samples lie near the margin.
For an RBF model, it may also reflect a more complex boundary.
A high count alone does not prove overfitting.

## 6.4 Effect of C on accuracy and support vectors

### Linear SVM

- **C = 0.1:** validation accuracy 72.58%–72.58%; support vectors 5849–5849.
- **C = 1:** validation accuracy 72.58%–72.58%; support vectors 5834–5834.
- **C = 10:** validation accuracy 72.58%–72.58%; support vectors 5837–5837.
- **C = 100:** validation accuracy 72.58%–72.58%; support vectors 5839–5839.

### RBF SVM

- **C = 0.1:** validation accuracy 95.00%–98.04%; support vectors 848–1347.
- **C = 1:** validation accuracy 97.50%–99.17%; support vectors 482–723.
- **C = 10:** validation accuracy 99.21%–99.62%; support vectors 342–381.
- **C = 100:** validation accuracy 99.54%–99.67%; support vectors 174–266.

C controls how strongly the SVM penalizes training errors and
margin violations. A small C allows more violations and generally
encourages a wider margin. A large C penalizes violations more
strongly and tries harder to classify the training samples correctly.

Validation accuracy does not necessarily increase as C increases.
The support-vector count can also rise or fall depending on the
dataset, kernel, and learned margin. Compare the actual results
above rather than assuming a fixed trend.

## 6.5 Is random-split test accuracy optimistic or pessimistic?

The test accuracy is likely **optimistic** as an estimate of
performance on genuinely new relay events. The rows are consecutive
time samples, but random splitting can place nearly identical
neighboring samples into both training and test sets.

Consequently, the test set may be easier than a real deployment
scenario involving a new fault event, different operating
conditions, measurement noise, or unseen patterns. A stronger
evaluation would split the data by complete fault events or
chronological time periods, keeping neighboring samples together.

## 6.6 Which model would I deploy for a relay?

Using the observed test results, **Best RBF SVM** has the
fewest missed faults among the four models; ties are resolved by
choosing the model with fewer false alarms.

It produced **6 missed faults**
and **4 false alarms** on the test set.

Missed faults are especially serious because the relay could fail
to detect a dangerous electrical fault. False alarms also matter
because they can cause unnecessary tripping and service disruption.
Therefore, both counts should be considered instead of accuracy alone.

This is a preliminary recommendation based on the supplied test
results. Before deployment, the model should be evaluated on
independent fault events, with particular attention to missed-fault
risk, response time, and reliability under realistic conditions.

## Appendix A — SVM validation results

| Kernel | C | Gamma | Validation Accuracy (%) | Support Vectors |
| --- | --- | --- | --- | --- |
| Linear | 0.10 | N/A | 72.58 | 5849 |
| Linear | 1.00 | N/A | 72.58 | 5834 |
| Linear | 10.00 | N/A | 72.58 | 5837 |
| Linear | 100.00 | N/A | 72.58 | 5839 |
| RBF | 0.10 | 0.10 | 95.00 | 1347 |
| RBF | 0.10 | 1.00 | 98.04 | 848 |
| RBF | 1.00 | 0.10 | 97.50 | 723 |
| RBF | 1.00 | 1.00 | 99.17 | 482 |
| RBF | 10.00 | 0.10 | 99.21 | 381 |
| RBF | 10.00 | 1.00 | 99.62 | 342 |
| RBF | 100.00 | 0.10 | 99.54 | 174 |
| RBF | 100.00 | 1.00 | 99.67 | 266 |

## Appendix B — Test results

Confusion matrices use the format [[TN, FP], [FN, TP]].

| Model | Accuracy (%) | TN | FP | FN | TP | Missed Faults |
| --- | --- | --- | --- | --- | --- | --- |
| Logistic Regression - Set R | 72.64 | 1305 | 0 | 657 | 439 | 657 |
| Logistic Regression - Set Q | 97.88 | 1299 | 6 | 45 | 1051 | 45 |
| Best Linear SVM | 73.59 | 1305 | 0 | 634 | 462 | 634 |
| Best RBF SVM | 99.58 | 1301 | 4 | 6 | 1090 | 6 |
