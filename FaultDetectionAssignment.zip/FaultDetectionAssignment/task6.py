
import os
import pandas as pd


# ==========================================
# TASK 6: ANALYSIS
# No tabulate package required
# ==========================================

BASE_DIR = r"C:\Users\Laptop Zone\Downloads\FaultDetectionAssignment"
RESULTS_DIR = os.path.join(BASE_DIR, "results")

TASK4_FILE = os.path.join(RESULTS_DIR, "task4_svm_results.csv")
TASK5_FILE = os.path.join(RESULTS_DIR, "task5_test_results.csv")
OUTPUT_FILE = os.path.join(RESULTS_DIR, "analysis.md")


# ==========================================
# 1. CHECK FILES
# ==========================================

for path in [TASK4_FILE, TASK5_FILE]:
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Required file not found:\n{path}\n"
            "Please run task4.py and task5.py first."
        )


# ==========================================
# 2. LOAD RESULTS
# ==========================================

svm_df = pd.read_csv(TASK4_FILE)
test_df = pd.read_csv(TASK5_FILE)

required_svm = {
    "Kernel", "C", "Gamma",
    "Validation Accuracy (%)", "Support Vectors"
}

required_test = {
    "Model", "Test Accuracy (%)",
    "TN", "FP", "FN", "TP", "Missed Faults"
}

if not required_svm.issubset(svm_df.columns):
    raise ValueError(
        "Task 4 CSV columns do not match the expected format.\n"
        f"Found: {list(svm_df.columns)}"
    )

if not required_test.issubset(test_df.columns):
    raise ValueError(
        "Task 5 CSV columns do not match the expected format.\n"
        f"Found: {list(test_df.columns)}"
    )


# ==========================================
# 3. HELPER: CREATE MARKDOWN TABLE MANUALLY
# ==========================================

def dataframe_to_markdown(dataframe):
    """Convert a DataFrame to a Markdown table without tabulate."""
    columns = list(dataframe.columns)

    def format_value(value):
        if pd.isna(value):
            return "N/A"
        if isinstance(value, float):
            return f"{value:.2f}"
        return str(value).replace("|", "\\|").replace("\n", " ")

    header = "| " + " | ".join(columns) + " |"
    separator = "| " + " | ".join("---" for _ in columns) + " |"

    rows = []
    for _, row in dataframe.iterrows():
        cells = [format_value(row[col]) for col in columns]
        rows.append("| " + " | ".join(cells) + " |")

    return "\n".join([header, separator] + rows)


# ==========================================
# 4. FIND BEST LINEAR AND RBF MODELS
# ==========================================

svm_df["Kernel"] = svm_df["Kernel"].astype(str).str.strip()

linear_df = svm_df[
    svm_df["Kernel"].str.lower() == "linear"
].copy()

rbf_df = svm_df[
    svm_df["Kernel"].str.lower() == "rbf"
].copy()

if linear_df.empty or rbf_df.empty:
    raise ValueError(
        "Task 4 results must contain both Linear and RBF models."
    )

best_linear = linear_df.sort_values(
    "Validation Accuracy (%)", ascending=False
).iloc[0]

best_rbf = rbf_df.sort_values(
    "Validation Accuracy (%)", ascending=False
).iloc[0]


# ==========================================
# 5. TASK 3 LOGISTIC REGRESSION RESULTS
# ==========================================

# From your Task 3 output
logistic_R_val_accuracy = 73.0833
logistic_Q_val_accuracy = 97.8333

weights_Q = {
    "Ia^2": 18.8912382991,
    "Ib^2": 4.7542559116,
    "Ic^2": 13.9569180396,
    "Va^2": -6.0276364341,
    "Vb^2": -6.4642583654,
    "Vc^2": -6.1407454567
}


# ==========================================
# 6. GET TASK 5 TEST RESULTS
# ==========================================

def get_test_result(model_name):
    matched = test_df[
        test_df["Model"].astype(str).str.strip() == model_name
    ]

    if matched.empty:
        raise ValueError(
            f"Task 5 result not found for: {model_name}\n"
            f"Available models: {test_df['Model'].tolist()}"
        )

    return matched.iloc[0]


test_R = get_test_result("Logistic Regression - Set R")
test_Q = get_test_result("Logistic Regression - Set Q")
test_linear = get_test_result("Best Linear SVM")
test_rbf = get_test_result("Best RBF SVM")


# ==========================================
# 7. VALIDATION ACCURACY AND SUPPORT VECTOR
#    SUMMARIES BY C
# ==========================================

def make_c_summary(kernel_df):
    lines = []

    for c_value in sorted(kernel_df["C"].unique()):
        group = kernel_df[kernel_df["C"] == c_value]

        min_acc = group["Validation Accuracy (%)"].min()
        max_acc = group["Validation Accuracy (%)"].max()

        min_sv = int(group["Support Vectors"].min())
        max_sv = int(group["Support Vectors"].max())

        lines.append(
            f"- **C = {c_value:g}:** validation accuracy "
            f"{min_acc:.2f}%–{max_acc:.2f}%; support vectors "
            f"{min_sv}–{max_sv}."
        )

    return "\n".join(lines)


linear_c_summary = make_c_summary(linear_df)
rbf_c_summary = make_c_summary(rbf_df)


# ==========================================
# 8. PREPARE CONFUSION MATRIX TEXT
# ==========================================

def confusion_text(result):
    return (
        f"[[{int(result['TN'])}, {int(result['FP'])}], "
        f"[{int(result['FN'])}, {int(result['TP'])}]]"
    )


# ==========================================
# 9. MODEL COMPARISON
# Prioritize fewer missed faults, then false alarms
# ==========================================

model_results = [
    ("Logistic Regression - Set R", test_R),
    ("Logistic Regression - Set Q", test_Q),
    ("Best Linear SVM", test_linear),
    ("Best RBF SVM", test_rbf)
]

ranked_models = sorted(
    model_results,
    key=lambda item: (
        int(item[1]["FN"]),
        int(item[1]["FP"])
    )
)

recommended_name, recommended_result = ranked_models[0]


# ==========================================
# 10. CREATE TABLES WITHOUT TABULATE
# ==========================================

validation_table = dataframe_to_markdown(svm_df)

test_table_df = pd.DataFrame([
    {
        "Model": name,
        "Accuracy (%)": round(float(result["Test Accuracy (%)"]), 2),
        "TN": int(result["TN"]),
        "FP": int(result["FP"]),
        "FN": int(result["FN"]),
        "TP": int(result["TP"]),
        "Missed Faults": int(result["Missed Faults"])
    }
    for name, result in model_results
])

test_table = dataframe_to_markdown(test_table_df)

weights_table_df = pd.DataFrame([
    {"Squared Feature": feature, "Weight": weight,
     "Sign": "Positive" if weight > 0 else "Negative"}
    for feature, weight in weights_Q.items()
])

weights_table = dataframe_to_markdown(weights_table_df)


# ==========================================
# 11. WRITE ANALYSIS REPORT
# ==========================================

report = f"""# Task 6 — Analysis

## 6.1 Logistic regression on Set R vs. linear SVM

Logistic regression on Set R achieved a validation accuracy of
**{logistic_R_val_accuracy:.2f}%**. The best linear SVM achieved
**{float(best_linear['Validation Accuracy (%)']):.2f}%** with
C = {float(best_linear['C']):g}.

Both models use the same six standardized electrical measurements
and learn a linear decision boundary. Logistic regression minimizes
logistic loss, while a linear SVM seeks a large-margin boundary.
Their accuracies can be similar because both are trying to separate
the same classes using a linear combination of the same features.

Similar performance suggests that a linear boundary captures some
of the relationship between the measurements and fault labels. It
does not prove that the classes are perfectly linearly separable.

## 6.2 Signs of the Set Q squared-feature weights

{weights_table}

The weights for all three squared-current features are positive.
This is consistent with many electrical faults causing current
magnitude to increase. When other features are held constant,
larger squared-current values tend to push the model toward the
fault class.

The weights for all three squared-voltage features are negative.
This is consistent with many faults causing voltage magnitude to
drop. Larger squared-voltage values tend to push the prediction
away from the fault class, while smaller values can support a
fault prediction.

These are learned statistical associations, not universal rules
for every fault type. Each weight must be interpreted together
with the other features and the standardization procedure.

## 6.3 Number of support vectors

The best linear SVM used **{int(best_linear['Support Vectors'])}**
support vectors. The best RBF SVM used
**{int(best_rbf['Support Vectors'])}** support vectors.

A very large number of support vectors means that many training
samples contribute to defining the decision boundary. This may
occur when classes overlap or many samples lie near the margin.
For an RBF model, it may also reflect a more complex boundary.
A high count alone does not prove overfitting.

## 6.4 Effect of C on accuracy and support vectors

### Linear SVM

{linear_c_summary}

### RBF SVM

{rbf_c_summary}

C controls how strongly the SVM penalizes training errors and
margin violations. A small C allows more violations and generally
encourages a wider margin. A large C penalizes violations more
strongly and tries harder to classify the training samples correctly.

Validation accuracy does not necessarily increase as C increases.
The support-vector count can also rise or fall depending on the
dataset, kernel, and learned margin. Compare the actual results
above rather than assuming a fixed trend.

## 6.5 Is random-split test accuracy optimistic or pessimistic?

The test accuracy is likely **optimistic** as an estimate of
performance on genuinely new relay events. The rows are consecutive
time samples, but random splitting can place nearly identical
neighboring samples into both training and test sets.

Consequently, the test set may be easier than a real deployment
scenario involving a new fault event, different operating
conditions, measurement noise, or unseen patterns. A stronger
evaluation would split the data by complete fault events or
chronological time periods, keeping neighboring samples together.

## 6.6 Which model would I deploy for a relay?

Using the observed test results, **{recommended_name}** has the
fewest missed faults among the four models; ties are resolved by
choosing the model with fewer false alarms.

It produced **{int(recommended_result['FN'])} missed faults**
and **{int(recommended_result['FP'])} false alarms** on the test set.

Missed faults are especially serious because the relay could fail
to detect a dangerous electrical fault. False alarms also matter
because they can cause unnecessary tripping and service disruption.
Therefore, both counts should be considered instead of accuracy alone.

This is a preliminary recommendation based on the supplied test
results. Before deployment, the model should be evaluated on
independent fault events, with particular attention to missed-fault
risk, response time, and reliability under realistic conditions.

## Appendix A — SVM validation results

{validation_table}

## Appendix B — Test results

Confusion matrices use the format [[TN, FP], [FN, TP]].

{test_table}
"""


# ==========================================
# 12. SAVE FILE
# ==========================================

with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
    file.write(report)

print("\nTASK 6 ANALYSIS GENERATED SUCCESSFULLY.")
print("Analysis saved to:")
print(OUTPUT_FILE)

print("\nBest Linear SVM:")
print("C =", best_linear["C"])
print(
    "Validation accuracy =",
    f"{float(best_linear['Validation Accuracy (%)']):.2f}%"
)
print("Support vectors =", int(best_linear["Support Vectors"]))

print("\nBest RBF SVM:")
print("C =", best_rbf["C"])
print("Gamma =", best_rbf["Gamma"])
print(
    "Validation accuracy =",
    f"{float(best_rbf['Validation Accuracy (%)']):.2f}%"
)
print("Support vectors =", int(best_rbf["Support Vectors"]))

print("\nPreliminary model comparison:")
print("Model =", recommended_name)
print("Missed faults =", int(recommended_result["FN"]))
print("False alarms =", int(recommended_result["FP"]))

print("\nTASK 6 FINISHED SUCCESSFULLY.")