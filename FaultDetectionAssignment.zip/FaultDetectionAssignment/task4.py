
import pandas as pd
import numpy as np
import os
import joblib

from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score


# ==========================================
# TASK 4: SUPPORT VECTOR MACHINES
# ==========================================

# 1. Load dataset
file_path = r"C:\Users\Laptop Zone\Downloads\FaultDetectionAssignment\data\detect_dataset.csv"

df = pd.read_csv(file_path)

# Keep the same columns as Task 3
feature_cols = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]
target_col = "Output (S)"

# Remove rows containing missing values in required columns
df = df[feature_cols + [target_col]].dropna().copy()

# Rename target and convert labels to integers
df["fault"] = df[target_col].astype(int)
df = df.drop(columns=[target_col])

X = df[feature_cols].to_numpy(dtype=float)
y = df["fault"].to_numpy(dtype=int)

print("Dataset loaded successfully.")
print("Dataset shape:", df.shape)
print("Class distribution:")
print(pd.Series(y).value_counts().sort_index())


# ==========================================
# 2. SAME TRAIN / VALIDATION / TEST SPLIT
# ==========================================

rng = np.random.default_rng(42)
idx = rng.permutation(len(df))

n_train = int(0.6 * len(df))
n_val = int(0.2 * len(df))

train_idx = idx[:n_train]
val_idx = idx[n_train:n_train + n_val]
test_idx = idx[n_train + n_val:]

X_train_raw = X[train_idx]
X_val_raw = X[val_idx]

y_train = y[train_idx]
y_val = y[val_idx]

print("\nTraining rows:", len(train_idx))
print("Validation rows:", len(val_idx))
print("Testing rows:", len(test_idx))


# ==========================================
# 3. STANDARDIZE SET R FEATURES
# Fit scaler ONLY on training data
# ==========================================

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train_raw)
X_val = scaler.transform(X_val_raw)

print("\nSet R features standardized successfully.")


# ==========================================
# 4. OUTPUT FOLDERS
# ==========================================

base_dir = r"C:\Users\Laptop Zone\Downloads\FaultDetectionAssignment"

model_dir = os.path.join(base_dir, "models")
results_dir = os.path.join(base_dir, "results")

os.makedirs(model_dir, exist_ok=True)
os.makedirs(results_dir, exist_ok=True)


# ==========================================
# 4.1 LINEAR SVM
# C = 0.1, 1, 10, 100
# ==========================================

C_values = [0.1, 1, 10, 100]

linear_results = []
best_linear_model = None
best_linear_accuracy = -1
best_linear_C = None

print("\n========== LINEAR SVM ==========")

for C in C_values:

    model = SVC(kernel="linear", C=C)

    # Train model
    model.fit(X_train, y_train)

    # Validation prediction
    y_pred = model.predict(X_val)

    # Validation accuracy
    accuracy = accuracy_score(y_val, y_pred)

    # Number of support vectors
    support_vectors = int(model.n_support_.sum())

    linear_results.append({
        "Kernel": "Linear",
        "C": C,
        "Gamma": "N/A",
        "Validation Accuracy (%)": accuracy * 100,
        "Support Vectors": support_vectors
    })

    print(
        f"C={C:<5} | "
        f"Validation Accuracy={accuracy * 100:.2f}% | "
        f"Support Vectors={support_vectors}"
    )

    # Keep the best linear model
    if accuracy > best_linear_accuracy:
        best_linear_accuracy = accuracy
        best_linear_model = model
        best_linear_C = C


# ==========================================
# 4.2 RBF SVM
# C = 0.1, 1, 10, 100
# Gamma = 0.1, 1
# ==========================================

gamma_values = [0.1, 1]

rbf_results = []
best_rbf_model = None
best_rbf_accuracy = -1
best_rbf_C = None
best_rbf_gamma = None

print("\n========== RBF SVM ==========")

for C in C_values:
    for gamma in gamma_values:

        model = SVC(
            kernel="rbf",
            C=C,
            gamma=gamma
        )

        # Train model
        model.fit(X_train, y_train)

        # Validation prediction
        y_pred = model.predict(X_val)

        # Validation accuracy
        accuracy = accuracy_score(y_val, y_pred)

        # Number of support vectors
        support_vectors = int(model.n_support_.sum())

        rbf_results.append({
            "Kernel": "RBF",
            "C": C,
            "Gamma": gamma,
            "Validation Accuracy (%)": accuracy * 100,
            "Support Vectors": support_vectors
        })

        print(
            f"C={C:<5} | "
            f"Gamma={gamma:<3} | "
            f"Validation Accuracy={accuracy * 100:.2f}% | "
            f"Support Vectors={support_vectors}"
        )

        # Keep the best RBF model
        if accuracy > best_rbf_accuracy:
            best_rbf_accuracy = accuracy
            best_rbf_model = model
            best_rbf_C = C
            best_rbf_gamma = gamma


# ==========================================
# 4.3 COMBINE RESULTS INTO A TABLE
# ==========================================

all_results = linear_results + rbf_results

results_df = pd.DataFrame(all_results)

# Display all results
print("\n========== TASK 4 RESULTS TABLE ==========")

print(
    results_df.to_string(
        index=False,
        formatters={
            "Validation Accuracy (%)": lambda x: f"{x:.2f}%"
        }
    )
)

# Save results table
results_path = os.path.join(results_dir, "task4_svm_results.csv")
results_df.to_csv(results_path, index=False)

print("\nResults table saved to:")
print(results_path)


# ==========================================
# 4.4 SAVE THE BEST MODELS USING JOBLIB
# ==========================================

linear_model_path = os.path.join(
    model_dir, "task4_best_linear_svm.joblib"
)

rbf_model_path = os.path.join(
    model_dir, "task4_best_rbf_svm.joblib"
)

joblib.dump(
    {
        "model": best_linear_model,
        "scaler": scaler,
        "feature_columns": feature_cols,
        "C": best_linear_C,
        "validation_accuracy": best_linear_accuracy
    },
    linear_model_path
)

joblib.dump(
    {
        "model": best_rbf_model,
        "scaler": scaler,
        "feature_columns": feature_cols,
        "C": best_rbf_C,
        "gamma": best_rbf_gamma,
        "validation_accuracy": best_rbf_accuracy
    },
    rbf_model_path
)


# ==========================================
# FINAL SUMMARY
# ==========================================

print("\n========== BEST MODELS ==========")

print("\nBest Linear SVM:")
print("C:", best_linear_C)
print(f"Validation Accuracy: {best_linear_accuracy * 100:.2f}%")

print("\nBest RBF SVM:")
print("C:", best_rbf_C)
print("Gamma:", best_rbf_gamma)
print(f"Validation Accuracy: {best_rbf_accuracy * 100:.2f}%")

print("\nSaved Linear SVM model:")
print(linear_model_path)

print("\nSaved RBF SVM model:")
print(rbf_model_path)

print("\nTASK 4 FINISHED SUCCESSFULLY.")

