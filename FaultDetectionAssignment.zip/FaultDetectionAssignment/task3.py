
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib

# Save plots reliably even when running from a terminal
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =========================================================
# TASK 3: LOGISTIC REGRESSION FROM SCRATCH
# =========================================================

FEATURES = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]
LEARNING_RATES = [0.01, 0.1, 1.0, 10.0]
N_ITERS = 2000
SEED = 42


# =========================================================
# 1. FIND AND LOAD DATASET
# =========================================================

def find_dataset():
    """Find detect_dataset.csv in common project locations."""

    script_folder = Path(__file__).resolve().parent
    current_folder = Path.cwd()

    candidates = [
        current_folder / "data" / "detect_dataset.csv",
        current_folder / "detect_dataset.csv",
        script_folder / "data" / "detect_dataset.csv",
        script_folder / "detect_dataset.csv",
    ]

    for path in candidates:
        if path.is_file():
            return path

    # Search one level below the project folder
    for folder in [current_folder, script_folder]:
        if folder.exists():
            matches = list(folder.glob("*/detect_dataset.csv"))
            if matches:
                return matches[0]

    raise FileNotFoundError(
        "\nCould not find detect_dataset.csv.\n"
        "Put the file in your project folder or its data folder.\n"
        f"Project/script folder: {script_folder}\n"
        f"Current folder: {current_folder}"
    )


data_path = find_dataset()
print("Dataset location:", data_path)

df = pd.read_csv(data_path)

# Remove accidental spaces from column names
df.columns = df.columns.astype(str).str.strip()

# Support the target column name used in your dataset
if "fault" not in df.columns:
    for possible_label in ["Output (S)", "Output(S)", "label"]:
        if possible_label in df.columns:
            df = df.rename(columns={possible_label: "fault"})
            break

required_columns = FEATURES + ["fault"]

missing_columns = [
    col for col in required_columns if col not in df.columns
]

if missing_columns:
    raise ValueError(
        f"\nMissing columns: {missing_columns}\n"
        f"Columns actually found: {df.columns.tolist()}"
    )

df = df[required_columns].copy()

# Convert every required column to numeric
for col in required_columns:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Remove rows with missing or invalid required values
before_cleaning = len(df)
df = df.replace([np.inf, -np.inf], np.nan)
df = df.dropna(subset=required_columns).reset_index(drop=True)

removed_rows = before_cleaning - len(df)

if removed_rows:
    print(
        f"Warning: removed {removed_rows} rows with missing, "
        "non-numeric or infinite values."
    )

if len(df) < 2:
    raise ValueError("Not enough valid rows to train the model.")

# The label must contain only 0 and 1
if not df["fault"].isin([0, 1]).all():
    raise ValueError(
        "The fault column must contain only 0 and 1. "
        f"Found: {sorted(df['fault'].unique().tolist())}"
    )

X_raw = df[FEATURES].to_numpy(dtype=np.float64)
y = df["fault"].to_numpy(dtype=np.int64)

print("\nDataset shape after cleaning:", df.shape)
print("Number of features in Set R:", len(FEATURES))
print("No fault (0):", int(np.sum(y == 0)))
print("Fault (1):", int(np.sum(y == 1)))

if len(np.unique(y)) < 2:
    raise ValueError(
        "The cleaned dataset must contain both fault=0 and fault=1."
    )


# =========================================================
# 2. SPLIT DATA: 60% TRAIN, 20% VALIDATION, 20% TEST
#    Exact random permutation method from Task 1
# =========================================================

rng = np.random.default_rng(SEED)
idx = rng.permutation(len(df))

n_train = int(0.6 * len(df))
n_val = int(0.2 * len(df))

train_idx = idx[:n_train]
val_idx = idx[n_train:n_train + n_val]
test_idx = idx[n_train + n_val:]

if len(train_idx) == 0 or len(val_idx) == 0:
    raise ValueError("Not enough rows for training and validation.")

y_train = y[train_idx]
y_val = y[val_idx]

print("\nData split:")
for split_name, split_idx in [
    ("Training", train_idx),
    ("Validation", val_idx),
    ("Testing", test_idx),
]:
    fraction = (
        np.mean(y[split_idx]) if len(split_idx) else float("nan")
    )
    print(
        f"{split_name}: {len(split_idx)} rows, "
        f"fault fraction = {fraction:.6f}"
    )


# =========================================================
# 3. LOGISTIC REGRESSION FUNCTIONS
# =========================================================

def sigmoid(z):
    """g(z) = 1 / (1 + exp(-z))."""
    z = np.asarray(z, dtype=np.float64)
    z = np.clip(z, -500, 500)
    return 1.0 / (1.0 + np.exp(-z))


def hypothesis(X, theta):
    """h_theta(X) = sigmoid(X @ theta)."""
    return sigmoid(X @ theta)


def cost(X, y, theta):
    """Average binary cross-entropy cost."""
    h = hypothesis(X, theta)

    # Required clipping before taking logarithms
    h = np.clip(h, 1e-12, 1 - 1e-12)

    return -np.mean(
        y * np.log(h) + (1 - y) * np.log(1 - h)
    )


def fit_logistic(X, y, alpha, n_iters):
    """
    Batch gradient descent:
    theta = theta + alpha/n * X.T @ (y - h)
    Starts from theta = 0 and records cost after each update.
    """
    n, m = X.shape
    theta = np.zeros(m, dtype=np.float64)
    history = []

    for iteration in range(n_iters):
        h = hypothesis(X, theta)

        gradient_update = (alpha / n) * (X.T @ (y - h))
        theta = theta + gradient_update

        current_cost = cost(X, y, theta)

        if not np.isfinite(current_cost) or not np.all(
            np.isfinite(theta)
        ):
            raise FloatingPointError(
                f"Numerical instability at iteration {iteration + 1}"
            )

        history.append(current_cost)

    return theta, np.array(history)


def predict(X, theta):
    """Predict 1 if probability >= 0.5; otherwise 0."""
    return (hypothesis(X, theta) >= 0.5).astype(int)


def accuracy(y_true, y_pred):
    """Classification accuracy."""
    return float(np.mean(y_true == y_pred))


# =========================================================
# 4. CREATE SET R AND SET Q
# =========================================================

# Set R: six raw features
X_R = X_raw.copy()
names_R = FEATURES.copy()

# Set Q: six raw features plus squares of the raw values
# Squares are calculated BEFORE standardization.
X_Q = np.column_stack([X_raw, X_raw ** 2])
names_Q = FEATURES + [name + "^2" for name in FEATURES]


def standardize(X, training_indices):
    """
    Standardize using training-set mean and population standard
    deviation. Apply those same statistics to all rows.
    """
    train_data = X[training_indices]

    mean = np.mean(train_data, axis=0)
    std = np.std(train_data, axis=0, ddof=0)

    # Avoid division by zero for constant features
    std[std == 0] = 1.0

    X_scaled = (X - mean) / std

    return X_scaled


# Standardize both feature sets separately using training rows only
X_R_std = standardize(X_R, train_idx)
X_Q_std = standardize(X_Q, train_idx)


def add_intercept(X):
    """Add the x0 = 1 column."""
    return np.column_stack([
        np.ones(X.shape[0], dtype=np.float64),
        X
    ])


X_R_all = add_intercept(X_R_std)
X_Q_all = add_intercept(X_Q_std)

X_R_train = X_R_all[train_idx]
X_R_val = X_R_all[val_idx]

X_Q_train = X_Q_all[train_idx]
X_Q_val = X_Q_all[val_idx]


# =========================================================
# 5. TEST LEARNING RATES AND PLOT COST
# =========================================================

plots_folder = data_path.parent.parent / "plots"
plots_folder.mkdir(parents=True, exist_ok=True)


def test_learning_rates(X_train, y_train, set_name):
    print("\n" + "=" * 65)
    print(f"LEARNING-RATE TEST: {set_name}")
    print("=" * 65)

    histories = {}
    stable_decreasing_rates = []

    for alpha in LEARNING_RATES:
        try:
            theta, history = fit_logistic(
                X_train, y_train, alpha, N_ITERS
            )

            histories[alpha] = history

            # Strictly decreasing at every recorded iteration.
            # No tolerance is used because the assignment says
            # the cost must decrease at every iteration.
            differences = np.diff(history)
            decreases_every_iteration = bool(
                np.all(differences < 0)
            )

            if decreases_every_iteration:
                stable_decreasing_rates.append(alpha)

            print(
                f"alpha={alpha:g} | "
                f"first cost={history[0]:.10f} | "
                f"final cost={history[-1]:.10f} | "
                f"minimum change={differences.min():.3e} | "
                f"decreases every iteration="
                f"{decreases_every_iteration}"
            )

        except (FloatingPointError, OverflowError) as error:
            print(f"alpha={alpha:g} failed: {error}")

    # Plot all successful learning-rate runs on one figure
    plt.figure(figsize=(10, 6))

    for alpha in LEARNING_RATES:
        if alpha in histories:
            plt.plot(
                np.arange(1, N_ITERS + 1),
                histories[alpha],
                label=f"alpha = {alpha:g}",
                linewidth=1.5
            )

    plt.xlabel("Iteration")
    plt.ylabel("Cost J(theta)")
    plt.title(f"{set_name}: Cost vs. Iteration")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    plot_path = plots_folder / f"task3_{set_name}_cost.png"
    plt.savefig(plot_path, dpi=200)
    plt.close()

    print("Cost plot saved:", plot_path)

    if stable_decreasing_rates:
        chosen_alpha = max(stable_decreasing_rates)
        print(
            f"Selected learning rate for {set_name}: "
            f"{chosen_alpha:g}"
        )
        return chosen_alpha

    print(
        f"No tested learning rate passed the strict decreasing "
        f"cost check for {set_name}."
    )
    return None


alpha_R = test_learning_rates(
    X_R_train, y_train, "Set_R"
)

alpha_Q = test_learning_rates(
    X_Q_train, y_train, "Set_Q"
)


# =========================================================
# 6. TRAIN FINAL MODELS AND REPORT ACCURACY + THETA
# =========================================================

def train_final_model(
    X_train, X_val, y_train, y_val,
    feature_names, alpha, set_name
):
    print("\n" + "=" * 65)
    print(f"FINAL MODEL: {set_name}")
    print("=" * 65)

    if alpha is None:
        print(
            "A final model was not selected because no tested "
            "learning rate passed the strict decreasing-cost check."
        )
        print(
            "Inspect the cost plot and learning-rate output. "
            "Do not report an unselected learning rate as valid."
        )
        return

    theta, history = fit_logistic(
        X_train, y_train, alpha, N_ITERS
    )

    train_predictions = predict(X_train, theta)
    val_predictions = predict(X_val, theta)

    train_acc = accuracy(y_train, train_predictions)
    val_acc = accuracy(y_val, val_predictions)

    print(f"Learning rate: {alpha:g}")
    print(f"Iterations: {N_ITERS}")
    print(f"Final training cost: {history[-1]:.10f}")
    print(f"Training accuracy: {train_acc:.4%}")
    print(f"Validation accuracy: {val_acc:.4%}")

    print("\nLearned theta parameters:")

    theta_names = ["theta_0"] + feature_names

    for name, value in zip(theta_names, theta):
        print(f"{name:>8} = {value:.10f}")


train_final_model(
    X_R_train, X_R_val,
    y_train, y_val,
    names_R, alpha_R, "Set R"
)

train_final_model(
    X_Q_train, X_Q_val,
    y_train, y_val,
    names_Q, alpha_Q, "Set Q"
)

print("\n" + "=" * 65)
print("TASK 3 FINISHED")
print("Check the plots folder for both cost graphs.")
print("=" * 65)