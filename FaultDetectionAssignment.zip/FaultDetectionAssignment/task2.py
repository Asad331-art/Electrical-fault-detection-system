
import os
import sys
import subprocess

# ==========================================================
# Check and install required libraries if missing
# ==========================================================

required_packages = {
    "numpy": "numpy",
    "pandas": "pandas",
    "matplotlib": "matplotlib"
}

missing_packages = []

for module, package in required_packages.items():
    try:
        __import__(module)
    except ImportError:
        missing_packages.append(package)

if missing_packages:
    print("Installing missing packages:", missing_packages)
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", *missing_packages]
    )

# Import libraries after checking installation
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# ==========================================================
# LOAD RAW DATA
# ==========================================================

# Load the CSV directly to avoid import-path problems
# when task2.py is in the project root.
data_path = Path("data") / "detect_dataset.csv"

if not data_path.exists():
    raise FileNotFoundError(
        f"Dataset not found at: {data_path.resolve()}\n"
        "Place detect_dataset.csv inside the data folder."
    )

df = pd.read_csv(data_path)

print("Original dataset shape:", df.shape)
print("Original columns:", df.columns.tolist())

# Rename actual target column
if "Output (S)" in df.columns:
    df = df.rename(columns={"Output (S)": "fault"})
elif "fault" not in df.columns:
    raise ValueError(
        "Cannot find the target column 'Output (S)' or 'fault'."
    )

# Columns required for the three plots
required_cols = ["Ia", "Ib", "Ic", "fault"]

missing_cols = [
    col for col in required_cols
    if col not in df.columns
]

if missing_cols:
    raise ValueError(
        f"Missing required columns: {missing_cols}"
    )

# Convert required columns to numeric
for col in required_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Report missing values before plotting
print("\nMissing values in plotting columns:")
print(df[required_cols].isnull().sum())

# Drop rows that cannot be plotted
df = df.dropna(subset=required_cols).reset_index(drop=True)

# Check fault labels
if not set(df["fault"].unique()).issubset({0, 1}):
    raise ValueError(
        "The fault column must contain only 0 and 1."
    )

if df.empty:
    raise ValueError("No valid rows remain after cleaning.")

print("\nRows used for plotting:", len(df))
print("No-fault rows:", (df["fault"] == 0).sum())
print("Fault rows:", (df["fault"] == 1).sum())

# Create folder to save figures
output_dir = Path("plots")
output_dir.mkdir(parents=True, exist_ok=True)

# ==========================================================
# TASK 2.1
# Ia, Ib, Ic against row number for first 2000 rows
# Shade background where fault = 1
# ==========================================================

print("\nCreating Plot 2.1...")

n = min(2000, len(df))
plot_df = df.iloc[:n].copy()

fig, ax = plt.subplots(figsize=(14, 6))

fault_values = plot_df["fault"].to_numpy()

# Shade continuous fault intervals
in_fault = False
start = 0

for i, value in enumerate(fault_values):
    if value == 1 and not in_fault:
        start = i
        in_fault = True

    elif value != 1 and in_fault:
        ax.axvspan(
            start - 0.5, i - 0.5,
            color="red", alpha=0.15
        )
        in_fault = False

if in_fault:
    ax.axvspan(
        start - 0.5, n - 0.5,
        color="red", alpha=0.15
    )

rows = np.arange(n)

ax.plot(rows, plot_df["Ia"], label="Ia", linewidth=0.8)
ax.plot(rows, plot_df["Ib"], label="Ib", linewidth=0.8)
ax.plot(rows, plot_df["Ic"], label="Ic", linewidth=0.8)

ax.set_title("Ia, Ib and Ic vs Row Number (First 2000 Rows)")
ax.set_xlabel("Row Number")
ax.set_ylabel("Current (Raw Units)")
ax.legend()
ax.grid(True, alpha=0.3)

fig.tight_layout()
fig.savefig(output_dir / "task2_1_currents_vs_row.png", dpi=300)
plt.show()
plt.close(fig)

print("Saved: plots/task2_1_currents_vs_row.png")

# ==========================================================
# TASK 2.2
# Scatter plot of Ia against Ib, coloured by fault
# ==========================================================

print("\nCreating Plot 2.2...")

fig, ax = plt.subplots(figsize=(8, 6))

no_fault = df[df["fault"] == 0]
fault = df[df["fault"] == 1]

ax.scatter(
    no_fault["Ia"], no_fault["Ib"],
    color="blue", label="No Fault (0)",
    alpha=0.6, s=15
)

ax.scatter(
    fault["Ia"], fault["Ib"],
    color="red", label="Fault (1)",
    alpha=0.6, s=15
)

ax.set_title("Ia vs Ib Coloured by Fault")
ax.set_xlabel("Ia (Raw Units)")
ax.set_ylabel("Ib (Raw Units)")
ax.legend()
ax.grid(True, alpha=0.3)

fig.tight_layout()
fig.savefig(output_dir / "task2_2_Ia_vs_Ib.png", dpi=300)
plt.show()
plt.close(fig)

print("Saved: plots/task2_2_Ia_vs_Ib.png")

# ==========================================================
# TASK 2.3
# Histogram of Ia for fault and no-fault rows
# ==========================================================

print("\nCreating Plot 2.3...")

fig, ax = plt.subplots(figsize=(8, 6))

# Common bin edges make the two distributions comparable
bin_edges = np.histogram_bin_edges(df["Ia"], bins=40)

ax.hist(
    no_fault["Ia"],
    bins=bin_edges,
    color="blue",
    alpha=0.6,
    label="No Fault (0)",
    density=True
)

ax.hist(
    fault["Ia"],
    bins=bin_edges,
    color="red",
    alpha=0.6,
    label="Fault (1)",
    density=True
)

ax.set_title("Histogram of Ia by Fault Class")
ax.set_xlabel("Ia (Raw Units)")
ax.set_ylabel("Density")
ax.legend()
ax.grid(True, alpha=0.3)

fig.tight_layout()
fig.savefig(output_dir / "task2_3_Ia_histogram.png", dpi=300)
plt.show()
plt.close(fig)

print("Saved: plots/task2_3_Ia_histogram.png")

# ==========================================================
# TASK 2 SUMMARY
# ==========================================================

print("\n" + "=" * 55)
print("TASK 2 COMPLETED")
print("=" * 55)

print("\nThree plots have been saved in:")
print(output_dir.resolve())

print("""
Plot 2.1 explanation:
The three phase currents are plotted against row number,
and red shading indicates rows labelled as faults.
Compare the current changes with the shaded intervals
to identify possible fault-related variations.

Plot 2.2 explanation:
The scatter plot compares Ia and Ib for both classes.
The amount of separation or overlap shows whether these
two current measurements can distinguish fault conditions.

Plot 2.3 explanation:
The overlaid histograms compare Ia for fault and no-fault
observations. Overlapping distributions indicate that Ia
alone may not perfectly distinguish the two classes.

Final question:
A single straight line can perfectly separate the classes
only if they are linearly separable in the Ia-Ib plane.
If fault and no-fault observations overlap, a single line
cannot perfectly separate them. Faults can change phase
current magnitudes and relationships, and different fault
conditions may produce similar current measurements.
Confirm the conclusion by inspecting Plot 2.2.
""")