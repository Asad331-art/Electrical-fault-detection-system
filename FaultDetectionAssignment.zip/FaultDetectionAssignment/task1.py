
import numpy as np
import pandas as pd
from src.load_data import load_raw

# ==================================================
# 1.1 LOAD AND INSPECT THE DATASET
# ==================================================

df = load_raw()

print("\n========== TASK 1.1 ==========")
print("Dataset Shape:", df.shape)
print("Column Names:", df.columns.tolist())
print("\nFirst Five Rows:")
print(df.head(5).to_string())

# ==================================================
# 1.2 CLEAN AND PREPARE THE DATA
# ==================================================

print("\n========== TASK 1.2 ==========")

# Remove automatically generated index columns
unnamed_cols = [
    col for col in df.columns
    if str(col).strip().lower().startswith("unnamed:")
]
df = df.drop(columns=unnamed_cols)

# Remove columns with no information (constant columns)
constant_cols = [
    col for col in df.columns
    if df[col].nunique(dropna=True) <= 1
]

# Do not remove the target column even if it is constant
constant_cols = [
    col for col in constant_cols
    if col != "Output (S)"
]

df = df.drop(columns=constant_cols)

print("Removed index columns:", unnamed_cols)
print("Removed constant columns:", constant_cols)

# Rename the actual label column
df = df.rename(columns={"Output (S)": "fault"})

print("\nUpdated Column Names:")
print(df.columns.tolist())

# Define the six measurement columns explicitly
feature_cols = ["Ia", "Ib", "Ic", "Va", "Vb", "Vc"]

# Check that all required columns exist
missing_columns = [
    col for col in feature_cols + ["fault"]
    if col not in df.columns
]

if missing_columns:
    raise ValueError(
        f"Required columns not found: {missing_columns}"
    )

# Keep only the six measurements and the target label
# Any other columns should first be inspected and documented.
extra_cols = [
    col for col in df.columns
    if col not in feature_cols + ["fault"]
]

if extra_cols:
    print("Additional columns removed:", extra_cols)
    df = df.drop(columns=extra_cols)

# Convert the six measurement columns to numeric
for col in feature_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Check data types
print("\nMeasurement Data Types:")
print(df[feature_cols].dtypes)

print("\nAre all six measurement columns numeric?")
print(
    df[feature_cols].dtypes.apply(
        lambda dtype: pd.api.types.is_numeric_dtype(dtype)
    )
)

# Report missing values per column
print("\nMissing Values Per Column:")
print(df.isnull().sum())

# ==================================================
# 1.3 COUNT NORMAL AND FAULT ROWS
# ==================================================

print("\n========== TASK 1.3 ==========")

print("Rows with fault = 1:", (df["fault"] == 1).sum())
print("Rows with fault = 0:", (df["fault"] == 0).sum())

# Verify target labels
if df["fault"].isnull().any():
    raise ValueError("The fault column contains missing values.")

if not set(df["fault"].unique()).issubset({0, 1}):
    raise ValueError(
        "The fault column must contain only 0 and 1."
    )

# Stop if any measurements are missing.
# Reported missing values must be handled before splitting.
if df[feature_cols].isnull().any().any():
    raise ValueError(
        "Measurement columns contain missing values. "
        "Handle them before splitting and standardizing."
    )

# ==================================================
# 1.4 SPLIT THE DATASET
# ==================================================

print("\n========== TASK 1.4 ==========")

# Exact splitting code required by the assignment
rng = np.random.default_rng(42)
idx = rng.permutation(len(df))
n_train, n_val = int(0.6 * len(df)), int(0.2 * len(df))
train_idx = idx[:n_train]
val_idx = idx[n_train:n_train + n_val]
test_idx = idx[n_train + n_val:]

# Create splits
train = df.iloc[train_idx].copy()
val = df.iloc[val_idx].copy()
test = df.iloc[test_idx].copy()

# Report rows and fraction of faults
for name, split in [
    ("Training", train),
    ("Validation", val),
    ("Testing", test)
]:
    fault_fraction = (split["fault"] == 1).mean()

    print(f"\n{name} Set")
    print("Number of rows:", len(split))
    print(f"Fault fraction: {fault_fraction:.6f}")

# ==================================================
# 1.5 STANDARDIZE THE SIX FEATURES
# ==================================================

print("\n========== TASK 1.5 ==========")

# Extract feature arrays
X_train = train[feature_cols].to_numpy(dtype=float)
X_val = val[feature_cols].to_numpy(dtype=float)
X_test = test[feature_cols].to_numpy(dtype=float)

# Calculate training mean and population standard deviation
train_mean = X_train.mean(axis=0)
train_std = X_train.std(axis=0, ddof=0)

if np.any(train_std == 0):
    raise ValueError(
        "A feature has zero training standard deviation."
    )

# Standardize using training statistics for every split
X_train_scaled = (X_train - train_mean) / train_std
X_val_scaled = (X_val - train_mean) / train_std
X_test_scaled = (X_test - train_mean) / train_std

# Display training statistics
print("\nTraining Means:")
print(pd.Series(train_mean, index=feature_cols))

print("\nTraining Standard Deviations:")
print(pd.Series(train_std, index=feature_cols))

print("\nScaled Training Means (approximately 0):")
print(pd.Series(
    X_train_scaled.mean(axis=0),
    index=feature_cols
))

print("\nScaled Training Standard Deviations (approximately 1):")
print(pd.Series(
    X_train_scaled.std(axis=0, ddof=0),
    index=feature_cols
))

# ==================================================
# SAVE PREPARED DATA
# ==================================================

from pathlib import Path

output_dir = Path("data/processed")
output_dir.mkdir(parents=True, exist_ok=True)

np.savez(
    output_dir / "prepared_data.npz",
    X_train=X_train_scaled,
    X_val=X_val_scaled,
    X_test=X_test_scaled,
    y_train=train["fault"].to_numpy(),
    y_val=val["fault"].to_numpy(),
    y_test=test["fault"].to_numpy(),
    feature_names=np.array(feature_cols),
    train_mean=train_mean,
    train_std=train_std
)

print("\nPrepared dataset saved successfully!")
print("Location: data/processed/prepared_data.npz")
print("\n========== TASK 1 COMPLETED ==========")